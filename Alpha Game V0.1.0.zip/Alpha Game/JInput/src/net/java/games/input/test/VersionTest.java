package net.java.games.input.test;

import net.java.games.input.Version;

public class VersionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("JInput version: " + Version.getVersion());
	}

}
