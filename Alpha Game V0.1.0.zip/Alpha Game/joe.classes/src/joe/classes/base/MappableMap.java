package joe.classes.base;

public class MappableMap<V1, V2> {

}
