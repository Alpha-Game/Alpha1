package joe.classes.language;

public interface IMessageChangeListener {
	void onChange(Message object, String oldString);
}
