package joe.classes.geometry2D;

public interface IShape2D {
	Rectangle2D getBoundRectnagle();
}
