package joe.classes.identifier;

public interface ITypable<V1> {
	Class<V1> getType();
}
