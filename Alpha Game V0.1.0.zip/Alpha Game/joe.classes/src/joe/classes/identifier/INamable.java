package joe.classes.identifier;

public interface INamable {
	String getDisplayNameIdentifier();
}
