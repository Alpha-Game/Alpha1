package match.layer;

import joe.game.platformer.effect.IEffectStateType;

public enum LayerEffectStateType implements IEffectStateType {
	Speed, Gravity, Gravity_Angle, Gravity_X, Gravity_Y;
}