package match.effect;

import joe.game.platformer.effect.IEffectOperatorType;

public enum EffectOperatorType implements IEffectOperatorType {
	Addition, Multiplcation, Value;
}
