package joe.game.layout.image.background;

import joe.game.layout.image.ImageDrawer;

public class ResizableBackground extends Background {
	public ResizableBackground(ImageDrawer image) {
		super(image);
	}
}