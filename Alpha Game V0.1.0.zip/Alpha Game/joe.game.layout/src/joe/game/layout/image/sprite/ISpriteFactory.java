package joe.game.layout.image.sprite;

public interface ISpriteFactory {
	ISprite getSprite();
}
