package joe.game.layout.image.background;

import joe.game.layout.image.ImageDrawer;
import joe.game.layout.image.ImageLayout;

public abstract class Background extends ImageLayout {
	public Background(ImageDrawer image) {
		super(image);
	}
}
