package joe.game.base.settings;

import joe.classes.identifier.IMappable;
import joe.classes.identifier.ITypable;

public interface ISettingType<V1> extends IMappable, ITypable<V1> {

}
