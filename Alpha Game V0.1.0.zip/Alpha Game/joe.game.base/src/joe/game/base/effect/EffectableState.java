package joe.game.base.effect;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import joe.classes.base.PriorityMap;
import joe.classes.identifier.IMappable;
import joe.classes.query.FailureCompoundResult;
import joe.game.base.IUpdateableObject;

public class EffectableState extends State implements IEffectableObject, IUpdateableObject {
	public static interface EffectCalculation<V1> {
		V1 nextState(IState nextState, IState lastState, IEffectableObject allStates);
	}
	
	protected final Set<IStateType<?>> fBaseTypes;
	protected final Map<IStateType<?>, EffectCalculation<?>> fCalculatedTypes;
	protected final Set<IStateType<?>> fInheritedTypes;
	protected final PriorityMap<IEffect, EffectValues> fEffects;
	protected final IState fBaseState;
	
	public EffectableState(String identifier, int previousStateCount) throws IllegalArgumentException {
		super(identifier, previousStateCount);
		fBaseState = createStateVariable();
		fBaseTypes = new HashSet<IStateType<?>>();
		fCalculatedTypes = new HashMap<IStateType<?>, EffectCalculation<?>>();
		fInheritedTypes = new HashSet<IStateType<?>>();
		fEffects = new PriorityMap<IEffect, EffectValues>();
	}
	
	public <V extends IStateType<?>> EffectableState(String identifier, int previousStateCount, Iterable<V> types) throws IllegalArgumentException {
		super(identifier, previousStateCount, types);
		fBaseState = createStateVariable();
		fBaseTypes = new HashSet<IStateType<?>>();
		fCalculatedTypes = new HashMap<IStateType<?>, EffectCalculation<?>>();
		fInheritedTypes = new HashSet<IStateType<?>>();
		fEffects = new PriorityMap<IEffect, EffectValues>();
	}
	
	public EffectableState(String identifier, int previousStateCount, IStateType<?>... types) throws IllegalArgumentException {
		super(identifier, previousStateCount, types);
		fBaseState = createStateVariable();
		fBaseTypes = new HashSet<IStateType<?>>();
		fCalculatedTypes = new HashMap<IStateType<?>, EffectCalculation<?>>();
		fInheritedTypes = new HashSet<IStateType<?>>();
		fEffects = new PriorityMap<IEffect, EffectValues>();
	}
	
	public <V1 extends IStateType<?>, V2 extends IStateType<?>, V3 extends IStateType<?>, V4 extends EffectCalculation<?>, V5 extends IStateType<?>, V6, V7>
		EffectableState(String identifier, int previousStateCount, Iterable<V1> types, Iterable<V2> baseTypes, Map<V3, V4> calculatedTypes, Iterable<V5> inheritedTypes, Map<V6, V7> startStates) throws IllegalArgumentException {
		this(identifier, previousStateCount, types);
		
		for (V2 baseType : baseTypes) {
			IStateType<?> realType = getEffectType(baseType);
			if (realType == null) {
				throw new IllegalArgumentException("Type cannot be null.");
			}
			fBaseTypes.add(realType);
		}
		
		for (Map.Entry<V3, V4> calculatedType : calculatedTypes.entrySet()) {
			IStateType<?> realType = getEffectType(calculatedType.getKey());
			if (realType == null) {
				throw new IllegalArgumentException("Type cannot be null.");
				
			} else if (calculatedType.getValue() == null) {
				throw new IllegalArgumentException("Calculation class cannot be null.");
			}
			fCalculatedTypes.put(realType, calculatedType.getValue());
		}
		
		for (V5 inheritedType : inheritedTypes) {
			IStateType<?> realType = getEffectType(inheritedType);
			if (realType == null) {
				throw new IllegalArgumentException("Type cannot be null.");
			}
			fInheritedTypes.add(realType);
		}
		
		IState startState = createStateVariable();
		for (Map.Entry<V6, V7> state : startStates.entrySet()) {
			IStateType<?> realType = getEffectType(state.getKey());
			V7 value = state.getValue();
			if (realType == null) {
				throw new IllegalArgumentException("Type cannot be null.");
			} else if ((value != null && !realType.getType().isInstance(value))) {
				throw new IllegalArgumentException("Value must match type.");
			}
			
			Object realValue = realType.getType().cast(value);
			if (fBaseTypes.contains(realType)) {
				fBaseState.setValue(this, realType, realValue);
			}
			startState.setValue(this, realType, realValue);
		}
		fStates.add(startState);
	}
	
	protected IState createState(IState lastState) {
		IState nextState = createStateVariable();
		lastState = new WhiteListStates(lastState);
		
		// Base states first
		for (IStateType<?> type : fBaseTypes) {
			if (nextState.getEffectType(type) != null) {
				nextState.setValue(this, type, fBaseState.getValue(type));
			}
		}
		
		// Inherited states next
		for (IStateType<?> type : fInheritedTypes) {
			if (nextState.getEffectType(type) != null) {
				nextState.setValue(this, type, lastState.getValue(type));
			}
		}
		
		// Calculated states last
		for (Map.Entry<IStateType<?>, EffectCalculation<?>> type : fCalculatedTypes.entrySet()) {
			if (nextState.getEffectType(type.getKey()) != null) {
				nextState.setValue(this, type, type.getValue().nextState(nextState, lastState, this));
			}
		}
		
		return nextState;
	}
	
	
	protected void applyEffects(long time, IState nextState) {
		List<IEffect> expiredEffects = new LinkedList<IEffect>();
		
		for (Map.Entry<IEffect, EffectValues> effect : fEffects.entrySet()) {
			EffectValues value = effect.getValue();
			
			if (value.fTime != null) {
				value.fTime = value.fTime - time;
				if (value.fTime < 0) {
					expiredEffects.add(effect.getKey());
					continue;
				}
			}
			
			value.fState.setState(nextState);
			effect.getKey().update(value.fTime == null ? IEffect.CONSTANT : time, value.fState);
		}
		
		removeEffect(this, expiredEffects);
	}
	
	@Override
	public void update(long time) {
		IState nextState = createState(fStates.get(0));
		applyEffects(time, nextState);
		fStates.add(nextState);
	}
	
	/*
	 * Modify Effect List
	 */
	protected boolean performEffect(IEffect effect, long time, IState state, Collection<IStateType<?>> allowedTypes) {
		return effect.update(time, new WhiteListStates(state, allowedTypes));
	}
	
	protected void addEffect(Long time, double priority, IEffect effect, Collection<IStateType<?>> allowedTypes) {
		fEffects.put(effect, priority, new EffectValues(new WhiteListCurrentState(allowedTypes), time));
	}
	
	protected void removeEffect(Object effect) {
		fEffects.remove(effect);
	}	
	
	/*
	 * Instant Effects
	 */

	@Override
	public boolean addInstantEffect(IEffect effect) {
		Collection<IStateType<?>> realTypes = getEffectType(effect.getTypesAffected());
		for (IStateType<?> type : realTypes) {
			if (!type.canAddInstantEffect()) {
				return false;
			}
		}
		return performEffect(effect, IEffect.INSTANTANEOUS, fStates.get(0), realTypes);
	}

	@Override
	public FailureCompoundResult<IEffect> addInstantEffect(IEffect... effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addInstantEffect(effect));
		}
		return result;
	}

	@Override
	public <V extends IEffect> FailureCompoundResult<IEffect> addInstantEffect(Collection<V> effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addInstantEffect(effect));
		}
		return result;
	}
	
	/*
	 * Base Effects
	 */

	@Override
	public boolean addBaseEffect(IEffect effect) {
		Collection<IStateType<?>> realTypes = getEffectType(effect.getTypesAffected());
		for (IStateType<?> type : realTypes) {
			if (!type.canAddBaseEffect()) {
				return false;
			}
		}
		return performEffect(effect, IEffect.BASE, fStates.get(0), realTypes);
	}

	@Override
	public FailureCompoundResult<IEffect> addBaseEffect(IEffect... effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addBaseEffect(effect));
		}
		return result;
	}

	@Override
	public <V extends IEffect> FailureCompoundResult<IEffect> addBaseEffect(Collection<V> effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addBaseEffect(effect));
		}
		return result;
	}
	
	/*
	 * Constant Effects
	 */

	@Override
	public boolean addConstantEffect(double priority, IEffect effect) {
		Collection<IStateType<?>> realTypes = getEffectType(effect.getTypesAffected());
		for (IStateType<?> type : realTypes) {
			if (!type.canAddConstantEffect()) {
				return false;
			}
		}
		addEffect(null, priority, effect, realTypes);
		return true;
	}

	@Override
	public FailureCompoundResult<IEffect> addConstantEffect(double priority, IEffect... effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addConstantEffect(priority, effect));
		}
		return result;
	}

	@Override
	public <V extends IEffect> FailureCompoundResult<IEffect> addConstantEffect(double priority, Collection<V> effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addConstantEffect(priority, effect));
		}
		return result;
	}
	
	/*
	 * Timed Effects
	 */

	@Override
	public boolean addTimedEffect(long time, double priority, IEffect effect) {
		Collection<IStateType<?>> realTypes = getEffectType(effect.getTypesAffected());
		for (IStateType<?> type : realTypes) {
			if (!type.canAddTimedEffect()) {
				return false;
			}
		}
		addEffect(time, priority, effect, realTypes);
		return true;
	}

	@Override
	public FailureCompoundResult<IEffect> addTimedEffect(long time, double priority, IEffect... effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addTimedEffect(time, priority, effect));
		}
		return result;
	}

	@Override
	public <V extends IEffect> FailureCompoundResult<IEffect> addTimedEffect(long time, double priority, Collection<V> effects) {
		FailureCompoundResult<IEffect> result = new FailureCompoundResult<IEffect>();
		for (IEffect effect : effects) {
			result.addResult(effect, addTimedEffect(time, priority, effect));
		}
		return result;
	}

	@Override
	public boolean addTimedEffect(double priority, ITimedEffect effect) {
		return addTimedEffect(effect.getDuration(), priority, effect);
	}

	@Override
	public FailureCompoundResult<ITimedEffect> addTimedEffect(double priority, ITimedEffect... effects) {
		FailureCompoundResult<ITimedEffect> result = new FailureCompoundResult<ITimedEffect>();
		for (ITimedEffect effect : effects) {
			result.addResult(effect, addTimedEffect(priority, effect));
		}
		return result;
	}

	@Override
	public <V extends ITimedEffect> FailureCompoundResult<ITimedEffect> addTimedEffect(double priority, Collection<V> effects) {
		FailureCompoundResult<ITimedEffect> result = new FailureCompoundResult<ITimedEffect>();
		for (ITimedEffect effect : effects) {
			result.addResult(effect, addTimedEffect(priority, effect));
		}
		return result;
	}
	
	/*
	 * Remove Effects
	 */

	@Override
	public boolean removeEffect(IMappable callingObject, Object effect) {
		removeEffect(effect);
		return true;
	}

	@Override
	public FailureCompoundResult<Object> removeEffect(IMappable callingObject, Object... effects) {
		FailureCompoundResult<Object> result = new FailureCompoundResult<Object>();
		for (Object effect : effects) {
			result.addResult(effect, removeEffect(callingObject, effect));
		}
		return result;
	}

	@Override
	public <V> FailureCompoundResult<V> removeEffect(IMappable callingObject, Collection<V> effects) {
		FailureCompoundResult<V> result = new FailureCompoundResult<V>();
		for (V effect : effects) {
			result.addResult(effect, removeEffect(callingObject, effect));
		}
		return result;
	}
	
	private static class EffectValues {
		WhiteListCurrentState fState;
		Long fTime;
		
		EffectValues(WhiteListCurrentState state, Long time) {
			fState = state;
			fTime = time;
		}
	}
	
	private class WhiteListCurrentState extends WhiteListStates {
		IState fState;
		
		protected WhiteListCurrentState(Collection<IStateType<?>> allowedTypes) {
			super(EffectableState.this, allowedTypes);
		}
		
		protected void setState(IState state) {
			fState = state;
		}
		
		@Override
		public boolean setValue(IMappable callingObject, Object type, Object value) {
			IStateType<?> realType = getEffectType(type);
			if (realType != null && fAllowedTypes.contains(realType) && (value == null || realType.getType().isInstance(value))) {
				return fState.setValue(callingObject, type, value);
			}
			return false;
		}
	}

	private static class WhiteListStates implements IState {
		protected final IState fParent;
		protected final Set<IStateType<?>> fAllowedTypes;
		
		protected WhiteListStates(IState parent) {
			fParent = parent;
			fAllowedTypes = new HashSet<IStateType<?>>();
		}
		
		protected WhiteListStates(IState parent, Collection<IStateType<?>> allowedTypes) {
			this(parent);
			for (IStateType<?> allowedType : allowedTypes) {
				fAllowedTypes.add(allowedType);
			}
		}

		@Override
		public boolean setValue(IMappable callingObject, Object type, Object value) {
			IStateType<?> realType = getEffectType(type);
			if (realType != null && fAllowedTypes.contains(realType) && (value == null || realType.getType().isInstance(value))) {
				return fParent.setValue(callingObject, realType, value);
			}
			return false;
		}

		@Override
		public <V> boolean setValue(IMappable callingObject, IStateType<V> type, V value) {
			return setValue(callingObject, (Object)type, (Object)value);
		}

		@Override
		public Object getValue(Object type) throws IllegalStateException {
			return fParent.getValue(type);
		}

		@Override
		public <V> V getValue(IStateType<V> type) throws IllegalStateException {
			return fParent.getValue(type);
		}

		@Override
		public IStateType<?> getEffectType(Object effectTypeID) {
			return fParent.getEffectType(effectTypeID);
		}

		@Override
		public Collection<IStateType<?>> getEffectType(Object... effectTypeID) {
			return fParent.getEffectType(effectTypeID);
		}

		@Override
		public <V> Collection<IStateType<?>> getEffectType(Collection<V> effectTypeID) {
			return fParent.getEffectType(effectTypeID);
		}

		@Override
		public Collection<IStateType<?>> getEffectType() {
			return fParent.getEffectType();
		}
		
	}
}
