package joe.game.base.effect;

import joe.classes.identifier.IMappable;

public interface IKillableObject extends IMappable {
	boolean isDead();
}
