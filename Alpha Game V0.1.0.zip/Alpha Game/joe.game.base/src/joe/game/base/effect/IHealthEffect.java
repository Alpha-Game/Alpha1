package joe.game.base.effect;

public interface IHealthEffect extends IEffect {
	IHealthDamageType getDamageType();
}
