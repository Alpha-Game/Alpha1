package joe.game.base.conditions;

public abstract class AbstractCondition implements ICondition {
	private final String fIdentifier;

	public AbstractCondition(String identifier) {
		fIdentifier = identifier;
	}

	@Override
	public String getIdentifier() {
		return fIdentifier;
	}
}
