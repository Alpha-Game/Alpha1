package joe.game.base.statistics;

import java.util.Collection;
import java.util.Map;

import joe.classes.identifier.TypedValueMap;

public class Statistics implements IStatisticableObject {
	private final TypedValueMap<IStatisticsType<?>> fMap;
	
	public Statistics() {
		fMap = new TypedValueMap<IStatisticsType<?>>();
	}
	
	public Statistics(IStatisticsType<?>... statisticType) {
		this();
		fMap.setType(statisticType);
	}
	
	public Object setStatistic(Object statisticType, Object statistic) {
		return fMap.setValue(statisticType, statistic);
	}
	
	public <V> V setStatistic(IStatisticsType<V> statisticType, V statistic) {
		return fMap.setValue(statisticType, statistic);
	}
	
	public Object removeStatistic(Object statisticType) {
		return fMap.removeValue(statisticType);
	}
	
	public Collection<Object> removeStatistics(Object... statisticType) {
		return fMap.removeValue(statisticType);
	}
	
	public Collection<Object> removeStatistics(Collection<Object> statisticType) {
		return fMap.removeValue(statisticType);
	}
	
	public void clearStatistics() {
		fMap.clearValues();
	}
	
	@Override
	public IStatisticsType<?> getStatisticType(Object statisticType) {
		return fMap.getType(statisticType);
	}
	
	@Override
	public Collection<IStatisticsType<?>> getStatisticType(Object... statisticType) {
		return fMap.getType(statisticType);
	}

	@Override
	public Collection<IStatisticsType<?>> getStatisticType(Collection<Object> statisticType) {
		return fMap.getType(statisticType);
	}

	@Override
	public Collection<IStatisticsType<?>> getStatisticType() {
		return fMap.getType();
	}

	@Override
	public <V> V getStatistic(IStatisticsType<V> statisticType) {
		return fMap.getValue(statisticType);
	}

	@Override
	public Object getStatistic(Object statisticType) {
		return fMap.getValue(statisticType);
	}

	@Override
	public Collection<Object> getStatistic(Object... statisticType) {
		return fMap.getValue(statisticType);
	}

	@Override
	public Collection<Object> getStatistic(Collection<Object> statisticType) {
		return fMap.getValue(statisticType);
	}

	@Override
	public Map<IStatisticsType<?>, Object> getStatistic() {
		return fMap.getValue();
	}
}
