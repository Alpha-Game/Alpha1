package joe.game.base;

import java.util.Collection;

import joe.classes.identifier.IMappable;

public interface IObjectContainer {
	boolean addObject(IMappable... objects);
	boolean addObject(Collection<IMappable> objects);
	
	IMappable getObject(Object objectOrObjectIDs);
	Collection<IMappable> getObjects(Object... objectOrObjectIDs);
	Collection<IMappable> getObjects(Collection<Object> objectOrObjectIDs);
	
	IMappable removeObject(Object objectOrObjectIDs);
	Collection<IMappable> removeObjects(Object... objectOrObjectIDs);
	Collection<IMappable> removeObjects(Collection<Object> objectOrObjectIDs);
}
