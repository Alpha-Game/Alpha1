package test.joe.game.layout;

import junit.framework.Test;
import junit.framework.TestSuite;

public class GameLayoutTestSuite extends TestSuite {
	public static Test suite()
    {
        TestSuite suite = new TestSuite("Joe.Game.Layout Test Suite");
        suite.addTestSuite(LayoutCalculatorTest.class);
        suite.addTestSuite(PositionTest.class);
        suite.addTestSuite(SpacableLayoutTest.class);
        return suite;
    }
}
