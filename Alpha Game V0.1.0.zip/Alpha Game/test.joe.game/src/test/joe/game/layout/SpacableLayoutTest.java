package test.joe.game.layout;

import java.awt.Graphics2D;

import joe.classes.geometry2D.Dimension2D;
import joe.classes.geometry2D.Rectangle2D;
import joe.game.layout.IDrawable;
import joe.game.layout.LayoutCalculator;
import joe.game.layout.SpacableLayout;
import junit.framework.TestCase;

public class SpacableLayoutTest extends TestCase {
	public void test_getDimension_NoImageSize_NoSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(0, 0);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		assertDimension(layout.getDimension(), 0, 0);
	}
	
	public void test_getDimension_PositiveImageSize_NoSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(10, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		assertDimension(layout.getDimension(), 10, 20);
	}
	
	public void test_getDimension_NoImageSize_PositiveSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(0, 0);
		SpacableLayout layout = createLayout(drawable, 5, 10, 15, 20);
		
		assertDimension(layout.getDimension(), 15, 35);
	}
	
	public void test_getDimension_PositiveImageSize_PositiveSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(10, 20);
		SpacableLayout layout = createLayout(drawable, 5, 10, 15, 20);
		
		assertDimension(layout.getDimension(), 25, 55);
	}
	
	public void test_getDimension_NoImageSize_NegativeSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(0, 0);
		SpacableLayout layout = createLayout(drawable, -5, -10, -15, -20);
		
		assertDimension(layout.getDimension(), 15, 35);
	}
	
	public void test_getDimension_PositiveImageSize_NegativeSpacerSize() throws Exception {
		DrawableMock drawable = createDrawable(10, 20);
		SpacableLayout layout = createLayout(drawable, -5, -10, -15, -20);
		
		assertDimension(layout.getDimension(), 25, 55);
	}
	
	public void test_getDimension_NegativeXImageSize() throws Exception {
		DrawableMock drawable = createDrawable(-10, 10);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.getDimension();
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_getDimension_NegativeYImageSize() throws Exception {
		DrawableMock drawable = createDrawable(10, -10);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.getDimension();
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_getDimension_NegativeXAndYImageSize() throws Exception {
		DrawableMock drawable = createDrawable(-10, -20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.getDimension();
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_draw_NoImageSize_NoSpacerSize_RightSize() throws Exception {
		DrawableMock drawable = createDrawable(0, 0);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 0, 0));
		
		assertEquals(0, drawable.getTotalUseCount());
	}
	
	public void test_draw_NoImageSize_NoSpacerSize_LargerSize() throws Exception {
		DrawableMock drawable = createDrawable(0, 0);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 10, 20));
		
		assertEquals(0, drawable.getTotalUseCount());
	}
	
	public void test_draw_NegativeXImageSize() throws Exception {
		DrawableMock drawable = createDrawable(-10, 10);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.draw(createGraphic(), createRectangle(0, 0, -10, 10));
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_draw_NegativeYImageSize() throws Exception {
		DrawableMock drawable = createDrawable(10, -10);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.draw(createGraphic(), createRectangle(0, 0, 10, -10));
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_draw_NegativeXAndYImageSize() throws Exception {
		DrawableMock drawable = createDrawable(-10, -20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		try {
			layout.draw(createGraphic(), createRectangle(0, 0, -10, -20));
			fail("No Exception thrown");
		} catch (RuntimeException ex) {
			// Test Passed
		}
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 16, 20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 8, 5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, 8, 5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 32, 60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, 32, 60);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -16, -20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -8, -5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, -8, -5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -32, -60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 0, 0, -32, -60);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 16, 20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 8, 5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, 8, 5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 32, 60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, 32, 60);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -16, -20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -8, -5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, -8, -5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -32, -60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 4, 5, -32, -60);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 16, 20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 8, 5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, 8, 5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 32, 60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, 32, 60);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_RightNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -16, -20));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_SmallerNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -8, -5));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, -8, -5);
	}
	
	public void test_draw_PositiveImageSize_NoSpacerSize_LargerNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 0, 0, 0, 0);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -32, -60));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -4, -5, -32, -60);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 22, 36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 2, 6, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 11, 12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 1, 2, 8, (double)20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerPositiveSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, 66, 72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 6, 12, 48, 40);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -22, -36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -2, -6, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -11, -12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -1, -2, -8, (double)-20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerNegativeSize_NoPoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(0, 0, -66, -72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -6, -12, -48, -40);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 22, 36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 6, 11, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 11, 12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 5, 7, 8, (double)20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerPositiveSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, 66, 72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 10, 17, 48, 40);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -22, -36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 2, -1, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -11, -12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 3, 3, -8, (double)-20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerNegativeSize_PositivePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(4, 5, -66, -72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -2, -7, -48, -40);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 22, 36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -2, 1, 16, 20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 11, 12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -3, -3, 8, (double)20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerPositiveSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, 66, 72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), 2, 7, 48, 40);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_RightNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -22, -36));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -6, -11, -16, -20);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_SmallerNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -11, -12));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -5, -7, -8, (double)-20/(double)3);
	}
	
	public void test_draw_PositiveImageSize_PositiveSpacerSize_LargerNegativeSize_NegativePoint() throws Exception {
		DrawableMock drawable = createDrawable(16, 20);
		SpacableLayout layout = createLayout(drawable, 2, 4, 6, 10);
		
		layout.draw(createGraphic(), createRectangle(-4, -5, -66, -72));
		
		assertEquals(1, drawable.getTotalUseCount());
		assertRectangle(drawable.getRectangle(0), -10, -17, -48, -40);
	}
	
	private SpacableLayout createLayout(IDrawable item, double spacerLeft, double spacerRight, double spacerTop, double spacerBottom) {
		return new SpacableLayout(item, spacerLeft, spacerRight, spacerTop, spacerBottom);
	}
	
	private DrawableMock createDrawable(double width, double height) {
		return new DrawableMock(LayoutCalculator.createDimension(width, height));
	}
	
	private Graphics2D createGraphic() {
		return null;
	}
	
	private Rectangle2D createRectangle(double x, double y, double width, double height) {
		return LayoutCalculator.createRectangle(x, y, width, height);
	}
	
	private void assertDimension(Dimension2D dimension, double width, double height) {
		assertEquals(width, dimension.getWidth());
		assertEquals(height, dimension.getHeight());
	}
	
	private void assertRectangle(Rectangle2D rectangle, double left, double top, double width, double height) {
		assertEquals(left, rectangle.getX());
		assertEquals(top, rectangle.getY());
		assertEquals(width, rectangle.getWidth());
		assertEquals(height, rectangle.getHeight());
		
		assertEquals(left, rectangle.getMinX());
		assertEquals(top, rectangle.getMinY());
		assertEquals((width / 2) + left, rectangle.getCenterX());
		assertEquals((height / 2) + top, rectangle.getCenterY());
		assertEquals(left + width, rectangle.getMaxX());
		assertEquals(top + height, rectangle.getMaxY());
	}
}
