package test.joe.game.layout;

import joe.classes.geometry2D.Dimension2D;
import joe.classes.geometry2D.Point2D;
import joe.classes.geometry2D.Rectangle2D;
import joe.game.layout.LayoutCalculator;
import joe.game.layout.Position;
import junit.framework.TestCase;

public class LayoutCalculatorTest extends TestCase {
	public void test_createPoint() throws Exception {
		final double x = 1.0;
		final double y = 2.0;
		
		Point2D point = LayoutCalculator.createPoint(1, 2);
		assertPoint(point, x, y);
	}
	
	public void test_createDimension() throws Exception {
		final double width = 1.0;
		final double height = 2.0;
		
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		assertDimension(dimension, width, height);
	}
	
	public void test_createRectangle_FourValues() throws Exception {
		final double left = 1.0;
		final double top = 2.0;
		final double width = 3.0;
		final double height = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createRectangle(left, top, width, height);
		assertRectangle(rectangle, left, top, width, height);
	}
	
	public void test_createBox_PositiveDimension() throws Exception {
		final double left = 1.0;
		final double top = 2.0;
		final double right = 3.0;
		final double bottom = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		assertRectangle(rectangle, left, top, right - left, bottom - top);
	}
	
	public void test_createBox_NegativeDimension() throws Exception {
		final double left = 4.0;
		final double top = 3.0;
		final double right = 2.0;
		final double bottom = 1.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		assertRectangle(rectangle, left, top, right - left, bottom - top);
	}
	
	public void test_createRectangle_TwoValues() throws Exception {
		final double left = 1.0;
		final double top = 2.0;
		final double width = 3.0;
		final double height = 4.0;
		
		Point2D point = LayoutCalculator.createPoint(left, top);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		
		Rectangle2D rectangle = LayoutCalculator.createRectangle(point, dimension);
		assertRectangle(rectangle, left, top, width, height);
	}
	
	public void test_getMarginRectangle_PositiveMargins_PositiveDimensions_PositivePoints() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = 1.0;
		final double topMargin = 2.0;
		final double rightMargin = 3.0;
		final double bottomMargin = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, (right - left) - (leftMargin + rightMargin), (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_NegativeMargins_PositiveDimensions_PositivePoints() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = -1.0;
		final double topMargin = -2.0;
		final double rightMargin = -3.0;
		final double bottomMargin = -4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, (right - left) - (leftMargin + rightMargin), (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_PositiveMargins_NegativeDimensions_PositivePoints() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = 1.0;
		final double topMargin = 2.0;
		final double rightMargin = 3.0;
		final double bottomMargin = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left - leftMargin, top - topMargin, (right - left) + (leftMargin + rightMargin), (bottom - top) + (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_NegativeMargins_NegativeDimensions_PositivePoints() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = -1.0;
		final double topMargin = -2.0;
		final double rightMargin = -3.0;
		final double bottomMargin = -4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left - leftMargin, top - topMargin, (right - left) + (leftMargin + rightMargin), (bottom - top) + (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_PositiveMargins_PositiveDimensions_NegativePoints() throws Exception {
		final double left = -20.0;
		final double top = -15.0;
		final double right = -10.0;
		final double bottom = -5.0;
		
		final double leftMargin = 1.0;
		final double topMargin = 2.0;
		final double rightMargin = 3.0;
		final double bottomMargin = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, (right - left) - (leftMargin + rightMargin), (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_NegativeMargins_PositiveDimensions_NegativePoints() throws Exception {
		final double left = -20.0;
		final double top = -15.0;
		final double right = -10.0;
		final double bottom = -5.0;
		
		final double leftMargin = -1.0;
		final double topMargin = -2.0;
		final double rightMargin = -3.0;
		final double bottomMargin = -4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, (right - left) - (leftMargin + rightMargin), (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_PositiveMargins_NegativeDimensions_NegativePoints() throws Exception {
		final double left = -5.0;
		final double top = -10.0;
		final double right = -15.0;
		final double bottom = -20.0;
		
		final double leftMargin = 1.0;
		final double topMargin = 2.0;
		final double rightMargin = 3.0;
		final double bottomMargin = 4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left - leftMargin, top - topMargin, (right - left) + (leftMargin + rightMargin), (bottom - top) + (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_NegativeMargins_NegativeDimensions_NegativePoints() throws Exception {
		final double left = -5.0;
		final double top = -10.0;
		final double right = -15.0;
		final double bottom = -20.0;
		
		final double leftMargin = -1.0;
		final double topMargin = -2.0;
		final double rightMargin = -3.0;
		final double bottomMargin = -4.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left - leftMargin, top - topMargin, (right - left) + (leftMargin + rightMargin), (bottom - top) + (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_LargePositiveLeftMargin_PositiveDimensions() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = 11.0;
		final double topMargin = 0.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, right, top + topMargin, 0, (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_LargePositiveRightMargin_PositiveDimensions() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 0.0;
		final double rightMargin = 11.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, 0, (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_LargePositiveTopMargin_PositiveDimensions() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 11.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, bottom, (right - left) - (leftMargin + rightMargin), 0);
	}
	
	public void test_getMarginRectangle_LargePositiveBottomMargin_PositiveDimensions() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 0.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 11.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top, (right - left) - (leftMargin + rightMargin), 0);
	}
	
	public void test_getMarginRectangle_LargePositiveLeftMargin_NegativeDimensions() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = 11.0;
		final double topMargin = 0.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, right, top + topMargin, 0, (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_LargePositiveRightMargin_NegativeDimensions() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 0.0;
		final double rightMargin = 11.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top + topMargin, 0, (bottom - top) - (topMargin + bottomMargin));
	}
	
	public void test_getMarginRectangle_LargePositiveTopMargin_NegativeDimensions() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 11.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 0.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, bottom, (right - left) - (leftMargin + rightMargin), 0);
	}
	
	public void test_getMarginRectangle_LargePositiveBottomMargin_NegativeDimensions() throws Exception {
		final double left = 20.0;
		final double top = 15.0;
		final double right = 10.0;
		final double bottom = 5.0;
		
		final double leftMargin = 0.0;
		final double topMargin = 0.0;
		final double rightMargin = 0.0;
		final double bottomMargin = 11.0;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		rectangle = LayoutCalculator.getMarginRectangle(rectangle, leftMargin, rightMargin, topMargin, bottomMargin);
		assertRectangle(rectangle, left + leftMargin, top, (right - left) - (leftMargin + rightMargin), 0);
	}	
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NoOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Top_Left;
		
		final double xOffset = 0.0;
		final double yOffset = 0.0;
		
		final double leftResult = left + xOffset;
		final double topResult = top + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_PositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Top_Left;
		
		final double xOffset = 1.0;
		final double yOffset = 2.0;
		
		final double leftResult = left + xOffset;
		final double topResult = top + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Top_Left;
		
		final double xOffset = -1.0;
		final double yOffset = -2.0;
		
		final double leftResult = left;
		final double topResult = top;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargePositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Top_Left;
		
		final double xOffset = 10.0;
		final double yOffset = 8.0;
		
		final double leftResult = right - width;
		final double topResult = bottom - height;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargeNegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Top_Left;
		
		final double xOffset = -10.0;
		final double yOffset = -8.0;
		
		final double leftResult = left;
		final double topResult = top;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NoOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 0, 0);
		
		assertRectangle(rectangle, 10, 0, 10, 20d * (10d/15d));
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_PositiveOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 1, 2);
		
		assertRectangle(rectangle, 10, 15d - (20d * (10d/15d)), 10, 20d * (10d/15d));
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NegativeOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0,10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 0, 0);
		
		assertRectangle(rectangle, 10, 0, 10, 20d * (10d/15d));
	}	
	
	public void test_getInnerRectangle_MiddleCenter_FitsWithin_NoOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Middle_Center;
		
		final double xOffset = 0.0;
		final double yOffset = 0.0;
		
		final double leftResult = (((right - left) / 2) + left) - (width / 2) + xOffset;
		final double topResult = (((bottom - top) / 2) + top) - (height / 2) + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_MiddleCenter_FitsWithin_WithPositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Middle_Center;
		
		final double xOffset = 4.0;
		final double yOffset = 2.0;
		
		final double leftResult = (((right - left) / 2) + left) - (width / 2) + xOffset;
		final double topResult = (((bottom - top) / 2) + top) - (height / 2) + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_MiddleCenter_FitsWithin_WithNegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Middle_Center;
		
		final double xOffset = -4.0;
		final double yOffset = -2.0;
		
		final double leftResult = (((right - left) / 2) + left) - (width / 2) + xOffset;
		final double topResult = (((bottom - top) / 2) + top) - (height / 2) + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_MiddleCenter_FitsWithin_LargePositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Middle_Center;
		
		final double xOffset = 5.0;
		final double yOffset = 4.0;
		
		final double leftResult = right - width;
		final double topResult = bottom - height;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_MiddleCenter_FitsWithin_LargeNegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Middle_Center;
		
		final double xOffset = -5.0;
		final double yOffset = -4.0;
		
		final double leftResult = left;
		final double topResult = top;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_MiddleCenter_TooBigX_NoOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(50, 5);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, 0, 0);
		
		assertRectangle(rectangle, 10, ((-5d * (10d/50d)) / 2d) + (15d/2d), 10, 5d * (10d/50d));
	}

	public void test_getInnerRectangle_MiddleCenter_TooBigY_NoOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(4, 30);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, 0, 0);
		
		assertRectangle(rectangle, ((-4d * (15d/30d)) / 2d) + (10d/2d)+ 10d, 0, 4d * (15d/30d), 15);
	}
	
	public void test_getInnerRectangle_MiddleCenter_TooBigX_WithPositiveOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(50, 5);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, 1, 2);
		
		assertRectangle(rectangle, 10, ((-5d * (10d/50d)) / 2d) + (15d/2d) + 2d, 10, 5d * (10d/50d));
	}
	
	public void test_getInnerRectangle_MiddleCenter_TooBigY_WithPositiveOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(4, 30);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, 1, 2);
		
		assertRectangle(rectangle, ((-4d * (15d/30d)) / 2d) + (10d/2d) + 1d + 10d, 0, 4d * (15d/30d), 15);
	}
	
	public void test_getInnerRectangle_MiddleCenter_TooBigX_WithNegativeOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(50, 5);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, -1, -2);
		
		assertRectangle(rectangle, 10, ((-5d * (10d/50d)) / 2d) + (15d/2d) - 2d, 10, 5d * (10d/50d));
	}
	
	public void test_getInnerRectangle_MiddleCenter_TooBigY_WithNegativeOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(4, 30);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Middle_Center, -1, -2);
		
		assertRectangle(rectangle, ((-4d * (15d/30d)) / 2d) + (10d/2d) - 1d + 10d, 0, 4d * (15d/30d), 15);
	}
	
	public void test_getInnerRectangle_BottomRight_FitsWithin_NoOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Bottom_Right;
		
		final double xOffset = 0.0;
		final double yOffset = 0.0;
		
		final double leftResult = (right - width) - xOffset;
		final double topResult = (bottom - height) - yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_BottomRight_FitsWithin_PositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Bottom_Right;
		
		final double xOffset = 1.0;
		final double yOffset = 2.0;
		
		final double leftResult = right - width;
		final double topResult = bottom - height;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_BottomRight_FitsWithin_NegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Bottom_Right;
		
		final double xOffset = -1.0;
		final double yOffset = -2.0;
		
		final double leftResult = (right - width) + xOffset;
		final double topResult = (bottom - height) + yOffset;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_BottomRight_FitsWithin_LargePositiveOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Bottom_Right;
		
		final double xOffset = 10.0;
		final double yOffset = 8.0;
		
		final double leftResult = right - width;
		final double topResult = bottom - height;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_BottomRight_FitsWithin_LargeNegativeOffsets() throws Exception {
		final double left = 5.0;
		final double top = 10.0;
		final double right = 15.0;
		final double bottom = 20.0;
		
		final double width = 2.0;
		final double height = 4.0;
		
		final Position position = Position.Bottom_Right;
		
		final double xOffset = -10.0;
		final double yOffset = -8.0;
		
		final double leftResult = left;
		final double topResult = top;
		final double widthResult = width;
		final double heightResult = height;
		
		Rectangle2D rectangle = LayoutCalculator.createBox(left, right, top, bottom);
		Dimension2D dimension = LayoutCalculator.createDimension(width, height);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, position, xOffset, yOffset);
		
		assertRectangle(rectangle, leftResult, topResult, widthResult, heightResult);
	}
	
	public void test_getInnerRectangle_BottomRight_TooBigX_NoOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(50, 5);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Bottom_Right, 0, 0);
		
		assertRectangle(rectangle, 10, (-5d * (10d/50d)) + 15d, 10, 5d * (10d/50d));
	}
	
	public void test_getInnerRectangle_BottomRight_TooBigY_NoOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(4, 30);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Bottom_Right, 0, 0);
		
		assertRectangle(rectangle, ((-4d * (15d/30d))) + 10d + 10d, 0, 4d * (15d/30d), 15);
	}
	
	public void test_getInnerRectangle_BottomRight_TooBigX_NegativeOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(50, 5);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Bottom_Right, -1, -2);
		
		assertRectangle(rectangle, 10, (-5d * (10d/50d)) + 15d - 2d, 10, 5d * (10d/50d));
	}
	
	public void test_getInnerRectangle_BottomRight_TooBigY_NegativeOffsets() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(10, 0, 10, 15);
		Dimension2D dimension = LayoutCalculator.createDimension(4, 30);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Bottom_Right, -1, -2);
		
		assertRectangle(rectangle, ((-4d * (15d/30d))) + 10d + 10d - 1d, 0, 4d * (15d/30d), 15);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NoOffsets_NegativeRectangle_PositiveDimensions() throws Exception {	
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(2, 4);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 0, 0);
		
		assertRectangle(rectangle, 20, 15, -2, -4);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_PositiveOffsets_NegativeRectangle_PositiveDimensions() throws Exception {		
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(2, 4);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 1, 2);
		
		assertRectangle(rectangle, 19, 13, -2, -4);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NegativeOffsets_NegativeRectangle_PositiveDimensions() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(2, 4);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, -1, -2);
		
		assertRectangle(rectangle, 20, 15, -2, -4);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargePositiveOffsets_NegativeRectangle_PositiveDimensions() throws Exception {		
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(2, 4);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 10, 15);
		
		assertRectangle(rectangle, 12, 4, -2, -4);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargeNegativeOffsets_NegativeRectangle_PositiveDimensions() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(2, 4);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, -10, -15);
		
		assertRectangle(rectangle, 20, 15, -2, -4);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NoOffsets_NegativeRectangle_PositiveDimensions() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 0, 0);
		
		assertRectangle(rectangle, 20, 15, -10, -15d * ((10d/15d) / (15d/20d)));
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_PositiveOffsets_NegativeRectangle_PositiveDimensions() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, 1, 2);
		
		assertRectangle(rectangle, 20, 15d * ((10d/15d) / (15d/20d)), -10, -15d * ((10d/15d) / (15d/20d)));
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NegativeOffsets_NegativeRectangle_PositiveDimensions() throws Exception {
		Rectangle2D rectangle = LayoutCalculator.createRectangle(20, 15, -10, -15);
		Dimension2D dimension = LayoutCalculator.createDimension(15, 20);
		rectangle = LayoutCalculator.getInnerRectangle(rectangle, dimension, Position.Top_Left, -1, -2);
		
		assertRectangle(rectangle, 20, 15, -10, -15d * ((10d/15d) / (15d/20d)));
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NoOffsets_PositiveRectangle_NegativeDimensions() throws Exception {	
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -2, -4, 0, 0);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_PositiveOffsets_PositiveRectangle_NegativeDimensions() throws Exception {		
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -2, -4, 1, 2);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NegativeOffsets_PositiveRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -2, -4, -1, -2);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargePositiveOffsets_PositiveRectangle_NegativeDimensions() throws Exception {		
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -2, -4, 10, 15);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargeNegativeOffsets_PositiveRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -2, -4, -10, -15);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NoOffsets_PositiveRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -15, -20, 0, 0);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_PositiveOffsets_PositiveRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -15, -20, 1, 2);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NegativeOffsets_PositiveRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 10, 0, 10, 15, -15, -20, -1, -2);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NoOffsets_NegativeRectangle_NegativeDimensions() throws Exception {	
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -2, -4, 0, 0);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_PositiveOffsets_NegativeRectangle_NegativeDimensions() throws Exception {		
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -2, -4, 1, 2);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_NegativeOffsets_NegativeRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -2, -4, -1, -2);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargePositiveOffsets_NegativeRectangle_NegativeDimensions() throws Exception {		
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -2, -4, 10, 15);
	}
	
	public void test_getInnerRectangle_TopLeft_FitsWithin_LargeNegativeOffsets_NegativeRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -2, -4, -10, -15);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NoOffsets_NegativeRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -15, -20, 0, 0);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_PositiveOffsets_NegativeRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -15, -20, 1, 2);
	}
	
	public void test_getInnerRectangle_TopLeft_TooBig_NegativeOffsets_NegativeRectangle_NegativeDimensions() throws Exception {
		doTestInnerRectangle(Position.Top_Left, 20, 15, -10, -15, -15, -20, -1, -2);
	}
	
	private double getScale(Rectangle2D outerRectangle, Dimension2D innerDimension) {
		double xWidthDelta = (Math.abs(outerRectangle.getWidth()) - Math.abs(innerDimension.getWidth()));
		double yHeightDelta = (Math.abs(outerRectangle.getHeight()) - Math.abs(innerDimension.getHeight()));
		double xWidthScale = 1;
		double yHeightScale = 1;
		
		// Calculate Width Delta and Width Scale
		if (xWidthDelta < 0) {
			xWidthScale = Math.abs(outerRectangle.getWidth() / innerDimension.getWidth());
		}
		// Calculate Height Delta and Height Scale
		if (yHeightDelta < 0) {
			yHeightScale = Math.abs(outerRectangle.getHeight() / innerDimension.getHeight());
		}
		
		// Keep the width to height ratio
		if (Math.abs(xWidthScale) < Math.abs(yHeightScale)) {
			return xWidthScale;
		} else {
			return yHeightScale;
		}
	}
	
	private double getFinalX(Position position, Rectangle2D outerRectangle, Dimension2D innerDimension, double xOffset, double xScale) {
		double delta = (Math.abs(Math.abs(outerRectangle.getWidth()) - Math.abs(xScale * innerDimension.getWidth())));
		if (position.isCenter() && delta / 2 < xOffset) {
			xOffset = delta / 2 * (xOffset < 0 ? -1 : 1);
		} else if (delta < xOffset) {
			xOffset = delta * (xOffset < 0 ? -1 : 1);
		}
		
		if (position.isCenter()) {
			return outerRectangle.getCenterX() - (Math.abs(xScale * innerDimension.getWidth()) / 2) + xOffset;
		} else if (outerRectangle.getWidth() < 0 && position.isRight()) {
			return outerRectangle.getMinX() - xOffset;
		} else if (outerRectangle.getWidth() < 0 && position.isLeft()) {
			return outerRectangle.getMaxX() + xOffset;
		} else if (outerRectangle.getWidth() > 0 && position.isRight()) {
			return outerRectangle.getMaxX() - xOffset;
		} else if (outerRectangle.getWidth() > 0 && position.isLeft()) {
			return outerRectangle.getMinX() + xOffset;
		}
		return Double.NaN;
	}
	
	private double getFinalY(Position position, Rectangle2D outerRectangle, Dimension2D innerDimension, double yOffset, double yScale) {
		double delta = (Math.abs(Math.abs(outerRectangle.getHeight()) - Math.abs(yScale * innerDimension.getHeight())));
		if (position.isMiddle() && delta / 2 < yOffset) {
			yOffset = delta / 2 * (yOffset < 0 ? -1 : 1);
		} else if (delta < yOffset) {
			yOffset = delta * (yOffset < 0 ? -1 : 1);
		}
		
		if (position.isCenter()) {
			return outerRectangle.getCenterX() - (Math.abs(yScale * innerDimension.getHeight()) / 2) + yOffset;
		} else if (outerRectangle.getHeight() < 0 && position.isRight()) {
			return outerRectangle.getMinY() - yOffset;
		} else if (outerRectangle.getHeight() < 0 && position.isLeft()) {
			return outerRectangle.getMaxY() + yOffset;
		} else if (outerRectangle.getHeight() > 0 && position.isRight()) {
			return outerRectangle.getMaxY() - yOffset;
		} else if (outerRectangle.getHeight() > 0 && position.isLeft()) {
			return outerRectangle.getMinY() + yOffset;
		}
		return Double.NaN;
	}
	
	private void assertInnerRectangle(Position position, Rectangle2D outerRectangle, Dimension2D innerDimension, Rectangle2D innerRectangle, double xOffset, double yOffset) {
		if (position.isLeft() && xOffset < 0) {
			xOffset = 0;
		} else if (position.isRight() && xOffset > 0) {
			xOffset = 0;
		}
		
		if (position.isTop() && yOffset < 0) {
			yOffset = 0;
		} else if (position.isBottom() && yOffset > 0) {
			yOffset = 0;
		}
		
		double scale = getScale(outerRectangle, innerDimension);
		double x = getFinalX(position, outerRectangle, innerDimension, xOffset, scale);
		double y = getFinalY(position, outerRectangle, innerDimension, yOffset, scale);
		double width = scale * Math.abs(innerDimension.getWidth());
		double height = scale * Math.abs(innerDimension.getHeight());
		
		if (!((outerRectangle.getWidth() < 0 && innerDimension.getWidth() < 0) || outerRectangle.getWidth() > 0 && innerDimension.getWidth() > 0)) {
			x = x + width;
			width *= -1;
		}
		if (!((outerRectangle.getHeight() < 0 && innerDimension.getHeight() < 0) || outerRectangle.getHeight() > 0 && innerDimension.getHeight() > 0)) {
			y = y + height;
			height *= -1;
		}
		assertRectangle(innerRectangle, x, y, width, height);
		assertIsInside(outerRectangle, innerRectangle);
	}
	
	private void assertIsBetween(double post1, double post2, double value) {
		if (post1 < post2) {
			if (!(post1 <= value && value <= post2)) {
				fail("Value <" + value + "> does not fall between Post <" + post1 + "> and Post <" + post2 + ">");
			}
		} else {
			if (!(post2 <= value && value <= post1)) {
				fail("Value <" + value + "> does not fall between Post <" + post2 + "> and Post <" + post1 + ">");
			}
		}
	}
	
	private void assertIsInside(Rectangle2D outerRectangle, Rectangle2D innerRectangle) {
		assertIsBetween(outerRectangle.getMinX(), outerRectangle.getMaxX(), innerRectangle.getMinX());
		assertIsBetween(outerRectangle.getMinX(), outerRectangle.getMaxX(), innerRectangle.getMaxX());
		assertIsBetween(outerRectangle.getMinY(), outerRectangle.getMaxY(), innerRectangle.getMinY());
		assertIsBetween(outerRectangle.getMinY(), outerRectangle.getMaxY(), innerRectangle.getMaxY());
	}
	
	private void doTestInnerRectangle(Position position, double rectX, double rectY, double rectWidth, double rectHeight, double dimWidth, double dimHeight, double xOffset, double yOffset) {
		Rectangle2D outerRectangle = LayoutCalculator.createRectangle(rectX, rectY, rectWidth, rectHeight);
		Dimension2D innerDimension = LayoutCalculator.createDimension(dimWidth, dimHeight);
		Rectangle2D innerRectangle = LayoutCalculator.getInnerRectangle(outerRectangle, innerDimension, position, xOffset, yOffset);
		
		assertInnerRectangle(position, outerRectangle, innerDimension, innerRectangle, xOffset, yOffset);
	}
	
	private void assertPoint(Point2D point, double x, double y) {
		assertEquals(x, point.getX());
		assertEquals(y, point.getY());
	}
	
	private void assertDimension(Dimension2D dimension, double width, double height) {
		assertEquals(width, dimension.getWidth());
		assertEquals(height, dimension.getHeight());
	}
	
	private void assertRectangle(Rectangle2D rectangle, double left, double top, double width, double height) {
		assertEquals(left, rectangle.getX());
		assertEquals(top, rectangle.getY());
		assertEquals(width, rectangle.getWidth());
		assertEquals(height, rectangle.getHeight());
		
		assertEquals(left, rectangle.getMinX());
		assertEquals(top, rectangle.getMinY());
		assertEquals((width / 2) + left, rectangle.getCenterX());
		assertEquals((height / 2) + top, rectangle.getCenterY());
		assertEquals(left + width, rectangle.getMaxX());
		assertEquals(top + height, rectangle.getMaxY());
	}
}
