package test.joe.game.layout;

import joe.game.layout.Position;
import junit.framework.TestCase;

public class PositionTest extends TestCase {
	public void test_Position_Top_Left() throws Exception {
		Position position = Position.Top_Left;
		
		// Test Left <-> Right Position
		assertEquals(true, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(true, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Top_Center() throws Exception {
		Position position = Position.Top_Center;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(true, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(true, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Top_Right() throws Exception {
		Position position = Position.Top_Right;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(true, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(true, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Middle_Left() throws Exception {
		Position position = Position.Middle_Left;

		// Test Left <-> Right Position
		assertEquals(true, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(true, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Middle_Center() throws Exception {
		Position position = Position.Middle_Center;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(true, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(true, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Middle_Right() throws Exception {
		Position position = Position.Middle_Right;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(true, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(true, position.isMiddle());
		assertEquals(false, position.isBottom());
	}
	
	public void test_Position_Bottom_Left() throws Exception {
		Position position = Position.Bottom_Left;

		// Test Left <-> Right Position
		assertEquals(true, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(true, position.isBottom());
	}
	
	public void test_Position_Bottom_Center() throws Exception {
		Position position = Position.Bottom_Center;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(true, position.isCenter());
		assertEquals(false, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(true, position.isBottom());
	}
	
	public void test_Position_Bottom_Right() throws Exception {
		Position position = Position.Bottom_Right;

		// Test Left <-> Right Position
		assertEquals(false, position.isLeft());
		assertEquals(false, position.isCenter());
		assertEquals(true, position.isRight());
		
		// Test Top <-> Bottom Position
		assertEquals(false, position.isTop());
		assertEquals(false, position.isMiddle());
		assertEquals(true, position.isBottom());
	}
}
