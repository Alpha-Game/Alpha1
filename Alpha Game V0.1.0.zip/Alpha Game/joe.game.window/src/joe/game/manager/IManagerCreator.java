package joe.game.manager;

import joe.game.base.settings.ICreator;

public interface IManagerCreator<V1 extends IGameManager, R1 extends IManager> extends ICreator<V1, R1> {

}
