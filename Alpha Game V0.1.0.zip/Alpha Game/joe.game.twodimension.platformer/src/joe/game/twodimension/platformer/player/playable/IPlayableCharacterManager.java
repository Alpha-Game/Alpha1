package joe.game.twodimension.platformer.player.playable;

import joe.game.twodimension.platformer.player.IPlayerManager;

public interface IPlayableCharacterManager extends IPlayerManager {

}
