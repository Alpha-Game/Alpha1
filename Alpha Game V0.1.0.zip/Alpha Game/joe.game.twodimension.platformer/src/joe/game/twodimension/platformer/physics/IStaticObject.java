package joe.game.twodimension.platformer.physics;

public interface IStaticObject extends ICollidableObject {

}
