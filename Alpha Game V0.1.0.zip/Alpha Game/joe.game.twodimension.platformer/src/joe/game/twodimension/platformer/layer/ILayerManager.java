package joe.game.twodimension.platformer.layer;

import java.util.Collection;

import joe.game.base.IObjectContainer;
import joe.game.base.effect.IEffectableObject;
import joe.game.base.settings.IHasSettingsObject;
import joe.game.base.statistics.IStatisticableObject;
import joe.game.twodimension.platformer.match.IMatchObject;
import joe.game.twodimension.platformer.player.IPlayerManager;
import joe.game.twodimension.platformer.tiles.ITileManager;

public interface ILayerManager extends IObjectContainer, IStatisticableObject, IEffectableObject, IMatchObject, IHasSettingsObject {
	IPlayerManager getPlayer(String playerID);
	Collection<IPlayerManager> getPlayers();
	Collection<IPlayerManager> getPlayers(String... playerIDs);
	Collection<IPlayerManager> getPlayers(Collection<Object> playerIDs);
	
	ITileManager getTile(String tileID);
	Collection<ITileManager> getTiles();
	Collection<ITileManager> getTiles(String... tileIDs);
	Collection<ITileManager> getTiles(Collection<Object> tileIDs);
	
	void setIsActive(boolean isActive);
	boolean isActive();
}
