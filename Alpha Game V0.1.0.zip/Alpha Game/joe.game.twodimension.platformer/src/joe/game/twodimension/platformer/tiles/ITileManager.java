package joe.game.twodimension.platformer.tiles;

import joe.game.base.settings.IHasSettingsObject;
import joe.game.twodimension.platformer.layer.ILayerObject;

public interface ITileManager extends ILayerObject, IHasSettingsObject {

}
