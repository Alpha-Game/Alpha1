package joe.game.twodimension.platformer.tiles;

import joe.game.twodimension.platformer.physics.IStaticObject;

public interface IStaticTileManager extends ICollidableTileManager, IStaticObject {

}
