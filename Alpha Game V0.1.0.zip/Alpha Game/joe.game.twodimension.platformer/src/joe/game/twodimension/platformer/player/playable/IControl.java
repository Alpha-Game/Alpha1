package joe.game.twodimension.platformer.player.playable;

public interface IControl {
	boolean isActive();
	double getScale();
}
