package joe.game.twodimension.platformer.tiles;

import joe.game.twodimension.platformer.physics.IMoveableObject;

public interface IMoveableTileManager extends ICollidableTileManager, IMoveableObject {

}
